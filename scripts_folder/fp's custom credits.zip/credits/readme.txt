The hard part is done for you.

Just copy paste the txt files into whatever song you want there to be credits for.

If the both of the txt files do not exist, the credits will not appear.

If one exists, but not the ohter, it shall be replaced with "Unknown".

Any places of note you can edit easily have been demarked with comments that start with "# ".

FREE TO USE, WITH CREDITS.
You may add them to whatever mod you're woking on without fear, BUT:
DONT REDISTRUBTE --JUST-- EDITS WITHOUT PRIOR PERMISSION. THANKS. -fp