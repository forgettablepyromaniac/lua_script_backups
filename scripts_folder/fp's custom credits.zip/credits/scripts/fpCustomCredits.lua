local artistName = 'Unknown'
local charterName = 'Unknown' -- don't actually edit these, wont do anything.
local redbookAudio = 0
local slightlyLeft = 0
local slightlyRight = 0
local orangebookAudio = 0
local greenbookAudio = 0
local purplebookAudio = 0

function onCreatePost() -- editable credits by FP, use with credits.
    redbookAudio = screenWidth / 2.5; -- declare variables.
    orangebookAudio = screenHeight / 3.5;
    bluebookAudio = screenHeight / 3;
    greenbookAudio = screenHeight / 2.5;
    purplebookAudio = screenHeight / 1.5;
    pinkbookAudio = screenHeight / 1.3; -- magic numbers.
    slightlyLeft = screenWidth / 3;
    slightlyRight = screenWidth / 3.5 + 8;
    if checkFileExists('data/'..songName..'/songCreatorName.txt') then
        artistName = getTextFromFile('data/'..songName..'/songCreatorName.txt'); -- could probably do a table for both in one txt.
    end
    if checkFileExists('data/'..songName..'/charterName.txt') then
        charterName = getTextFromFile('data/'..songName..'/charterName.txt'); -- I am lazy though and therefore don't care. suck it.
    end
    if charterName == "Unknown" then
        if artistName == "Unknown" then
            Function_Stop();
        end
    end -- If there is no info to show, there is no reason to continue.
    -- debugPrint('NAME: ', artistName);
    -- debugPrint('SHARTER: ', charterName);
    -- debugPrint('SONG: ', songName);
    -- debugPrint('THE SONG NAME: ', theSongName);

    makeLuaSprite('creditBackground', 'empty', 0, 0);
	makeGraphic('creditBackground', redbookAudio, screenHeight, '000000'); -- # the final string is the colour of the box in HEX.
	setObjectCamera('creditBackground', 'camHUD');
    setProperty('creditBackground.alpha', 0.5); -- today I learned you can do setProperty with your own sprites. Useful to know.
	addLuaSprite('creditBackground', false);
    screenCenter('creditBackground', 'xy');

    makeLuaText('theSongName', '"'..songName..'"', redbookAudio, redbookAudio, bluebookAudio); -- stupid dumb unoptimized code.
	setTextAlignment('theSongName', 'center');
	setTextFont('theSongName', 'vcr.ttf'); -- # fonts also need to be picked out individually. VCR.TTF should be built into psych, tho.
    setTextColor('theSongName', 'ffffff') -- # feel free to edit the colour to whatever you want. use HEX.
	setTextSize('theSongName', 56);
    addLuaText('theSongName');
    screenCenter('theSongName', 'x');

	makeLuaText('artistText', 'Artist:', redbookAudio, slightlyLeft, orangebookAudio);
	setTextAlignment('artistText', 'left');
	setTextFont('artistText', 'vcr.ttf');
    setTextColor('artistName', 'ffffff');
	setTextSize('artistText', 48);
    addLuaText('artistText');

    makeLuaText('artistName', artistName, redbookAudio, slightlyRight, greenbookAudio);
	setTextAlignment('artistName', 'right');
	setTextFont('artistName', 'vcr.ttf');
    setTextColor('artistName', 'ff9900'); -- # If you want specific colours per artist or per charter, add a "if artistName == name, else"
	setTextSize('artistName', 40);
    addLuaText('artistName');
    
	makeLuaText('charterText', 'Charter:', redbookAudio, slightlyLeft, purplebookAudio);
	setTextAlignment('charterText', 'left');
	setTextFont('charterText', 'vcr.ttf'); 
    setTextColor('charterName', 'ffffff')
	setTextSize('charterText', 48);
    addLuaText('charterText');

    makeLuaText('charterName', charterName, redbookAudio, slightlyRight, pinkbookAudio);
	setTextAlignment('charterName', 'right');
	setTextFont('charterName', 'vcr.ttf');
    setTextColor('charterName', 'ff9900'); 
	setTextSize('charterName', 40);
    addLuaText('charterName');
end

function onBeatHit()
    if curBeat == 8 then -- # too fast? set this higher. Also, feel free to do "if songname == song then, else" for a specific song or 2.
        doTweenAlpha('tweenMeDaddy', 'theSongName', 0, 1, 'sineInOut')
        doTweenAlpha('tweenMeDaddy2', 'artistText', 0, 1, 'sineInOut')
        doTweenAlpha('tweenMeDaddy3', 'artistName', 0, 1, 'sineInOut')
        doTweenAlpha('tweenMeDaddy4', 'creditBackground', 0, 1, 'sineInOut')
        doTweenAlpha('tweenMeDaddy5', 'charterName', 0, 1, 'sineInOut')
        doTweenAlpha('tweenMeDaddy6', 'charterText', 0, 1, 'sineInOut')
    end
end