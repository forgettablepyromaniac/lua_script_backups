-- by forgettablePyromaniac, use with credit. Deleting credits just ain't cool, bro. https://forgettablepyromaniac.neocities.org/

-- Everything below is fully customizable.
-- Should go lowest -> hightest, could be a bit fucky otherwise.
-- At minimum, should have a 100% and 0% percentage on the table, with at least one that doesn't require FC status.
-- default table entry for refrence: {name = "S", percentage = 0.95, requiresFC = false}

-- When checking the ratings table, it checks for the required FC one first, which allows you to have multiple ratings on the same %
-- Example:
-- (When FCing with the default table, and over 95 percent, it'll say "S+". If not FCing and over 95, it'll show just "S")

local ratingsTable = {
    {name = "F", percentage = 0, requiresFC = false},
    {name = "D", percentage = 0.6, requiresFC = false},
    {name = "Nice", percentage = 0.69, requiresFC = false},
    {name = "C", percentage = 0.7, requiresFC = false},
    {name = "B", percentage = 0.8, requiresFC = false},
    {name = "A", percentage = 0.9, requiresFC = false},
    {name = "S", percentage = 0.95, requiresFC = false},
    {name = "S+", percentage = 0.95, requiresFC = true},
    {name = "P", percentage = 1, requiresFC = true}
}

local scoreName = "Score" -- name for score. call it points, call it bingus-credits, idfk. String.
local missesName = "Misses" -- name for misses. amount of times yo bitchass couldn't hit notes, basically. String.

local showFullComboStatus = true -- if you want ([FC]) to show up beside your new rating when hitting a full combo. Boolean.
local fcNames = { -- The Names of the FC statuses. They Should be in this specific order in order to avoid errors. If one is blank, it'll not show anything.
    "SFC", -- SFC
    "GFC", -- GFC
    "FC", -- FC
    "SDCB", -- SDCB
    "Clear" -- Clear
}

newRatingText = "Rating" -- The inital custom rating before anything hits. Change if you wanna change that thing, I guess. String.
fullWomboCombo = "" -- Keep Blank unless you want something to show up before the FC Status does. Reccomended to put between []. String.
newRatingPercentage = "?%" -- If you want a custom percentage before the song starts, edit that shit here. String, include % sign.

newFont = "vcr.ttf" -- name of font file you want to use. Should be stored in the mod's fonts folder. try "comicsans.ttf", it comes included w/ the test mod.
changingTxtColour = true -- decides whether or not to enable colour changing depending on dadName & boyfriendName.
scoreTxtColour = "FFFFFF" -- if changingTxtColour is false, or colourTable is malformed, this will be the Colour of the text in Hexadecimal: RRGGBB (Red, Green, Blue). String.
colourTable = { -- colours for each person, opponents and players. Should be fairly obvious, I hope.
    {oppoName = "dad", colour = "8A00E6"},
    {oppoName = "spooky", colour = "FFB366"}, 
    {oppoName = "pico", colour = "00FF00"},
    {oppoName = "mom", colour = "E60073"},
    {oppoName = "mom-car", colour = "E60073"},
    {oppoName = "parents-christmas", colour = "E600E6"},
    {oppoName = "senpai", colour = "80BFFF"},
    {oppoName = "senpai-angry", colour = "80BFFF"},
    {oppoName = "spirit", colour = "FF0000"},
    {oppoName = "tankman", colour = "FFFFFF"},
    {oppoName = "monster", colour = "FFFF00"},
    {oppoName = "monster-christmas", colour = "FFFF00"},
    {playerName = "bf", colour = "00FFFF"},
    {playerName = "bf-car", colour = "00FFFF"},
    {playerName = "bf-christmas", colour = "00FFFF"},
    {playerName = "bf-pixel", colour = "00FFFF"},
    {playerName = "bf-holding-gf", colour = "00FFFF"}
}

songsBfStarts = { -- due to a technical thing, you should specificy which songs start with the camera pointed toward BF. This was the best way i found to do this.
    'Tutorial',
    'Dad Battle',
    "Spookeez",
    "South",
    "Monster",
    "Pico",
    "Philly Nice",
    'Blammed',
    "High",
    "Milf",
    "Eggnog",
    "Winter Horrorland",
    "Guns"
}

-- If you need to figure out the name of the song, either check the top right of the pause menu while in-game or use debugPrint(songName)

-- options below were added so if ur not doing anything else with the botPlay or timeBar already, you can keep visual consistency.
allowBotStuff = true -- Changes BotText to the Colours and Font above if set to true. Boolean.
allowTimeStuff = true -- Same as above, but for the timeBar. Boolean.
txtWhyOffset = 0 -- because sometimes the text gets missaligned when using other fonts. Use this to fix that. Number Value.
scoreWhyOffset = 0 -- same as above. Not really nessicary compared to the txt offset, but it's nice to have just in case. Number Value.

possibleBotTexts = { -- chance should equal 100. chance is the percent chance to achive that string upon starting a song. Default: {string = "BOTPLAY", chance = 100}
    {string = "BOTPLAY", chance = 100}
}

turnOffRatingOnBotplay = true -- says in the score section that no rating will be given since botPlay is on. Slightly weird if botplay is toggled on mid-level (like in charting mode.)
noRatingsText = "None (Botplay is enabled)" -- what the newRatingPercentage will be replaced with when botPlay and turnOffRatingOnBotplay are enabled.

-- everything below is related to code. Don't touch shit unless you know what ur doing. -- 
-- everything below is related to code. Don't touch shit unless you know what ur doing. -- 
-- everything below is related to code. Don't touch shit unless you know what ur doing. -- 

-- im spamming it so that people dont fuck with the code ok

local defaultFCNames = { -- because I couldn't think of a better way to do this. DONT FUCKING EDIT THIS.
    "SFC",
    "GFC",
    "FC",
    "SDCB",
    "Clear"
}

local bfNewColour = scoreTxtColour
local oppoNewColour = scoreTxtColour

function convertRatingToPercentage(intake)
    local tempIntake = intake * 100
    local output = string.format("%.1f", tempIntake)
    if string.sub(output, -2) == ".0" then
        return string.sub(output, 1, -3) .. "%"
    else
        return output .. "%"
    end
end

function createProperRatingNames(coolness)
    for i = #ratingsTable, 1, -1 do
        local makeItEasy = ratingsTable[i]
        if coolness >= makeItEasy.percentage then
            if misses <= 0 and makeItEasy.requiresFC then
                return makeItEasy.name
            elseif not makeItEasy.requiresFC then
                return makeItEasy.name
            end
        end
    end
end

function getRandomBotplayTxt() -- I have a headache.
    local totalChance = 0
    for w, erf in ipairs(possibleBotTexts) do
        totalChance = totalChance + erf.chance
    end
    local randomValue = math.random(0, 100)
    if totalChance ~= 100 then
        debugPrint("Total chance is not 100. Defaulting to BOTPLAY.")
        return "BOTPLAY"
    end
    local cumulativeChance = 0
    for w, erf in ipairs(possibleBotTexts) do
        cumulativeChance = cumulativeChance + erf.chance
        if randomValue <= cumulativeChance then
            return erf.string
        end
    end
end

function overwriteFCNames(defaultFCName) -- couldn't think of a better way to do this.
    local customName = nil
    if defaultFCName == "SFC" then
        customName = fcNames[1]
    elseif defaultFCName == "GFC" then
        customName = fcNames[2]
    elseif defaultFCName == "FC" then
        customName = fcNames[3]
    elseif defaultFCName == "SDCB" then
        customName = fcNames[4]
    elseif defaultFCName == "Clear" then
        customName = fcNames[5]
    else
        customName = "" -- how did you even achive this if ur following direction wtf
    end
    if customName ~= "" then
        return "["..customName.."]"
    else
        return customName
    end
    
end

function setProperColours(input1, input2)
    for h, oof in ipairs(colourTable) do
        if oof.oppoName == input1 then
            bfNewColour = oof.colour
        elseif oof.playerName == input2 then
            oppoNewColour = oof.colour
        end
    end
    return {oppoNewColour, bfNewColour}
end

function doingColourStuffAgain()
    if not changingTxtColour then
        setTextColor('scoreTxt', scoreTxtColour)
        setTextColor('botplayTxt', scoreTxtColour)
        setTextColor('timeTxt', scoreTxtColour)
    else
        if mustHitSection then
            setTextColor('scoreTxt', bfFinalColour)
            setTextColor('botplayTxt', bfFinalColour)
            setTextColor('timeTxt', bfFinalColour)
        else
            setTextColor('scoreTxt', oppoFinalColour)
            setTextColor('botplayTxt', oppoFinalColour)
            setTextColor('timeTxt', oppoFinalColour)
        end
    end
end

function okDoItNow()
    if rating == 0 and misses == 0 then
        -- debugPrint('bro') -- intentionally left blank.
    else
        newRatingPercentage = convertRatingToPercentage(rating)
        newRatingText = createProperRatingNames(rating)
    end
    if showFullComboStatus then
        if rating > 0 then
            fullWomboCombo = overwriteFCNames(ratingFC)
        end
    end
    if botPlay and turnOffRatingOnBotplay then
        newRatingPercentage = noRatingsText
        fullWomboCombo = ""
    end
    setTextString('scoreTxt', scoreName..': '..score..' | '..missesName..': '..misses..' | '..newRatingText..' - '..newRatingPercentage..' '..fullWomboCombo)
end

function onCreatePost()
    setTextFont('scoreTxt', newFont)
    if allowBotStuff then
        setTextFont('botplayTxt', newFont)
    end
    if allowTimeStuff then
        setTextFont('timeTxt', newFont)
    end
    finalizedTable = setProperColours(dadName, boyfriendName)
    oppoFinalColour = finalizedTable[2]
    bfFinalColour = finalizedTable[1]
    alreadyChecked = false
    for h, weh in ipairs(songsBfStarts) do
        if weh == songName then
            setTextColor('scoreTxt', bfFinalColour)
            setTextColor('botplayTxt', bfFinalColour)
            setTextColor('timeTxt', bfFinalColour)
            alreadyChecked = true
        else
            if not alreadyChecked then
                setTextColor('scoreTxt', oppoFinalColour)
                setTextColor('botplayTxt', oppoFinalColour)
                setTextColor('timeTxt', oppoFinalColour)
            end
        end
    end
    math.randomseed(os.time()) -- for randomeness :3
    if showFullComboStatus then
        if #fcNames ~= 5 then
            debugPrint("Error: The fcNames table should contain exactly five entries.")
            fcNames = defaultFCNames
        end
    else
        fcNames = defaultFCNames
    end
    txtWhyOffset = getProperty("timeTxt.y") - txtWhyOffset -- subtract instead of add, because belive it or not, adding to Y should go UP, not down.
    scoreWhyOffset = getProperty("scoreTxt.y") - scoreWhyOffset -- you fucking clowns.
    setProperty("timeTxt.y", txtWhyOffset)
    setProperty("scoreTxt.y", scoreWhyOffset)
    setTextString('botplayTxt', getRandomBotplayTxt())
end

function onUpdatePost(elapsed) -- switched from update to updatePost because otherwise there was a bug that when u miss it would cause the original bar to pop up for a frame or 2 when missing.
    okDoItNow()  -- feels cleaner if I put this in it's own function.
end

function onSectionHit()
    doingColourStuffAgain()
end