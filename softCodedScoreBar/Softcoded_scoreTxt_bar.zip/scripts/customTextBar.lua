-- by forgettablePyromaniac, use with credit. Deleting credits just ain't cool, bro. https://forgettablepyromaniac.neocities.org/

-- Everything below is fully customizable.
-- Should go lowest -> hightest, could be a bit fucky otherwise.
-- At minimum, should have a 100% and 0% percentage on the table, with at least one that doesn't require FC status.
-- default table entry for refrence: {name = "S", percentage = 0.95, requiresFC = false}

-- When checking the ratings table, it checks for the required FC one first, which allows you to have multiple ratings on the same %
-- Example:
-- (When FCing with the default table, and over 95 percent, it'll say "S+". If not FCing and over 95, it'll show just "S")

local ratingsTable = {
    {name = "F", percentage = 0, requiresFC = false},
    {name = "D", percentage = 0.6, requiresFC = false},
    {name = "Nice", percentage = 0.69, requiresFC = false},
    {name = "C", percentage = 0.7, requiresFC = false},
    {name = "B", percentage = 0.8, requiresFC = false},
    {name = "A", percentage = 0.9, requiresFC = false},
    {name = "S", percentage = 0.95, requiresFC = false},
    {name = "S+", percentage = 0.95, requiresFC = true},
    {name = "P", percentage = 1, requiresFC = true}
}

local scoreName = "Score" -- name for score. call it points, call it bingus-credits, idfk. String.
local missesName = "Misses" -- name for misses. amount of times yo bitchass couldn't hit notes, basically. String.

local showFullComboStatus = true -- if you want ([FC]) to show up beside your new rating when hitting a full combo. Boolean.
local fcNames = { -- The Names of the FC statuses. They Should be in this specific order in order to avoid errors. If one is blank, it'll not show anything.
    "SFC", -- SFC
    "GFC", -- GFC
    "FC", -- FC
    "SDCB", -- SDCB
    "Clear" -- Clear
}

newRatingText = "Rating" -- The inital custom rating before anything hits. Change if you wanna change that thing, I guess. String.
fullWomboCombo = "" -- Keep Blank unless you want something to show up before the FC Status does. String.
newRatingPercentage = "?%" -- If you want a custom percentage before the song starts, edit that shit here. String, include % sign.

scoreTxtColour = "FFFFFF" -- Colour of the TextBar in Hexadecimal: RRGGBB (Red, Green, Blue). String.
newFont = "vcr.ttf" -- name of font file you want to use. Should be stored in the mod's fonts folder. try "comicsans.ttf", it comes included w/ the test mod.
allowBotStuff = true -- Changes BotText to the stuff above if set to true. Not sure why you'd want to, but just in case. Boolean.

possibleBotTexts = { -- chance should equal 100. chance is the percent chance to achive that string upon starting a song. Default: {string = "BOTPLAY", chance = 100}
    {string = "BOTPLAY", chance = 100}
}

-- everything below is related to code. Don't touch shit unless you know what ur doing. -- 
-- everything below is related to code. Don't touch shit unless you know what ur doing. -- 
-- everything below is related to code. Don't touch shit unless you know what ur doing. -- 
-- everything below is related to code. Don't touch shit unless you know what ur doing. -- 
-- everything below is related to code. Don't touch shit unless you know what ur doing. -- 

-- im spamming it so that people dont fuck with the code ok

local defaultFCNames = { -- because I couldn't think of a better way to do this. DONT FUCKING EDIT THIS.
    "SFC",
    "GFC",
    "FC",
    "SDCB",
    "Clear"
}

function convertRatingToPercentage(intake)
    local tempIntake = intake * 100
    local output = string.format("%.1f", tempIntake)
    if string.sub(output, -2) == ".0" then
        return string.sub(output, 1, -3) .. "%"
    else
        return output .. "%"
    end
end

function createProperRatingNames(coolness)
    for i = #ratingsTable, 1, -1 do
        local makeItEasy = ratingsTable[i]
        if coolness >= makeItEasy.percentage then
            if misses <= 0 and makeItEasy.requiresFC then
                return makeItEasy.name
            elseif not makeItEasy.requiresFC then
                return makeItEasy.name
            end
        end
    end
end

function getRandomBotplayTxt() -- I have a headache.
    local totalChance = 0
    for w, erf in ipairs(possibleBotTexts) do
        totalChance = totalChance + erf.chance
    end
    local randomValue = math.random(0, 100)
    if totalChance ~= 100 then
        debugPrint("Total chance is not 100. Defaulting to BOTPLAY.")
        return "BOTPLAY"
    end
    local cumulativeChance = 0
    for w, erf in ipairs(possibleBotTexts) do
        cumulativeChance = cumulativeChance + erf.chance
        if randomValue <= cumulativeChance then
            return erf.string
        end
    end
end

function overwriteFCNames(defaultFCName) -- couldn't think of a better way to do this.
    local customName = nil
    if defaultFCName == "SFC" then
        customName = fcNames[1]
    elseif defaultFCName == "GFC" then
        customName = fcNames[2]
    elseif defaultFCName == "FC" then
        customName = fcNames[3]
    elseif defaultFCName == "SDCB" then
        customName = fcNames[4]
    elseif defaultFCName == "Clear" then
        customName = fcNames[5]
    else
        customName = "" -- how did you even achive this if ur following direction wtf
    end
    if customName ~= "" then
        return "["..customName.."]"
    else
        return customName
    end
    
end

function onCreatePost()
    setTextColor('scoreTxt', scoreTxtColour)
    setTextFont('scoreTxt', newFont)
    if allowBotStuff then
        setTextColor('botplayTxt', scoreTxtColour)
        setTextFont('botplayTxt', newFont)
    end
    math.randomseed(os.time()) -- for randomeness :3
    if #fcNames ~= 5 then
        debugPrint("Error: The fcNames table should contain exactly five entries.")
        fcNames = defaultFCNames
    end
    setTextString('botplayTxt', getRandomBotplayTxt())
end

function onUpdate(elapsed)
    if rating == 0 and misses == 0 then
        -- debugPrint('bro') -- intentionally left blank.
    else
        newRatingPercentage = convertRatingToPercentage(rating)
        newRatingText = createProperRatingNames(rating)
    end
    if showFullComboStatus then
        if rating > 0 then
            fullWomboCombo = overwriteFCNames(ratingFC)
        end
    end
    setTextString('scoreTxt', scoreName..': '..score..' | '..missesName..': '..misses..' | '..newRatingText..' - '..newRatingPercentage..' '..fullWomboCombo)
end